package com.geek.silenceap.util;

import com.geek.silenceap.https.HttpsClientRequestFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * 调用第三方http util 包装类
 * https://blog.csdn.net/justry_deng/article/details/82531306
 */
@Service
public class HttpClient {

    @Autowired
    JSONUtil jsonUtil;

    public String getHttp(String url) {
        RestTemplate template = new RestTemplate();

        // -------------------------------> 解决(响应数据可能)中文乱码 的问题
        List<HttpMessageConverter<?>> converterList = template.getMessageConverters();
        converterList.remove(1); // 移除原来的转换器

        // 设置字符编码为utf-8
        HttpMessageConverter<?> converter = new StringHttpMessageConverter(StandardCharsets.UTF_8);
        converterList.add(1, converter); // 添加新的转换器(注:convert顺序错误会导致失败)
        template.setMessageConverters(converterList);

        // -------------------------------> (选择性设置)请求头信息
        // HttpHeaders实现了MultiValueMap接口
        HttpHeaders headers = new HttpHeaders();
        // 给请求header中添加一些数据
        headers.add("JustryDeng", "这是一个大帅哥!");
        headers.add("key1", "not cn");
        headers.add("phone", "18385099999");

//        // -------------------------------> 注:GET请求 创建HttpEntity时,请求体传入null即可
//        // 请求体的类型任选即可;只要保证 请求体 的类型与HttpEntity类的泛型保持一致即可
        String httpBody = null;
        HttpEntity<String> httpEntity = new HttpEntity<String>(httpBody, headers);

//        // -------------------------------> URI
//        StringBuffer paramsURL = new StringBuffer("http://127.0.0.1:9527/restTemplate/doHttpGet");
//        // 字符数据最好encoding一下;这样一来，某些特殊字符才能传过去(如:flag的参数值就是“&”,不encoding的话,传不过去)
//        paramsURL.append("?flag=" + URLEncoder.encode("&", "utf-8"));
//        URI uri = URI.create(paramsURL.toString());
        URI uri = URI.create(url);

//        //  -------------------------------> 执行请求并返回结果
//        // 此处的泛型  对应 响应体数据   类型;即:这里指定响应体的数据装配为String
        ResponseEntity<String> response = template.exchange(uri, HttpMethod.GET, httpEntity, String.class);
        return response.getBody();
    }

    public String postHttp(String url, Object o) {
        // -------------------------------> 获取Rest客户端实例
        RestTemplate restTemplate = new RestTemplate();

        // -------------------------------> 解决(响应数据可能)中文乱码 的问题
        List<HttpMessageConverter<?>> converterList = restTemplate.getMessageConverters();
        converterList.remove(1); // 移除原来的转换器
        // 设置字符编码为utf-8
        HttpMessageConverter<?> converter = new StringHttpMessageConverter(StandardCharsets.UTF_8);
        converterList.add(1, converter); // 添加新的转换器(注:convert顺序错误会导致失败)
        restTemplate.setMessageConverters(converterList);

        // -------------------------------> (选择性设置)请求头信息
        // HttpHeaders实现了MultiValueMap接口
        HttpHeaders httpHeaders = new HttpHeaders();
        // 设置contentType
        httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
        // 给请求header中添加一些数据
        httpHeaders.add("JustryDeng", "这是一个大帅哥!");

// ------------------------------->将请求头、请求体数据，放入HttpEntity中
        // 请求体的类型任选即可;只要保证 请求体 的类型与HttpEntity类的泛型保持一致即可
        // 这里手写了一个json串作为请求体 数据 (实际开发时,可使用fastjson、gson等工具将数据转化为json串)
//        String httpBody = "{\"motto\":\"唉呀妈呀！脑瓜疼！\"}";
        HttpEntity<String> httpEntity = new HttpEntity<String>(jsonUtil.toJSONString(o), httpHeaders);

        URI uri = URI.create(url);
        ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.POST, httpEntity, String.class);

        return response.getBody();
    }

    public String getHttps(String url) {
        // Https 获取RestTemplate实例
        RestTemplate restTemplate = new RestTemplate(new HttpsClientRequestFactory());

        URI uri = URI.create(url);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
        return response.getBody();
    }
}
