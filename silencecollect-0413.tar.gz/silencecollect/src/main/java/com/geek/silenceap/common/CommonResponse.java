package com.geek.silenceap.common;


import com.geek.silenceap.util.JSONUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CommonResponse {

    private Logger logger = LoggerFactory.getLogger(CommonResponse.class);

    private int code;
    private String message;
    private Object data;

    public int getCode() {
        return code;
    }

    public CommonResponse setCode(ResponseCode responseCode) {
        this.code = responseCode.code;
        return this;
    }

    public CommonResponse setCode(int responseCode) {
        this.code = responseCode;
        return this;
    }

    public String getMessage() {
        return message;
    }

    public CommonResponse setMessage(String message) {
        this.message = message;
        return this;
    }

    public Object getData() {
        return data;
    }

    public CommonResponse setData(Object data) {
        this.data = data;
        return this;
    }

    @Override
    public String toString() {
        String jsonStr = JSONUtil.toJSONString(this);
        logger.info("CommonResponse toString : {}",jsonStr);
        return jsonStr;
    }
}
