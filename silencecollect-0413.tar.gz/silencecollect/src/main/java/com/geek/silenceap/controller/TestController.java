package com.geek.silenceap.controller;

import com.geek.silenceap.bean.HttpBean;
import com.geek.silenceap.util.HttpClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@EnableAutoConfiguration
@RequestMapping("/test")
public class TestController {

    @Autowired
    HttpClient httpClient;

    @RequestMapping("/httpGet")
    public void httpTest() {
        String url = "https://www.baidu.com/";
        String response = httpClient.getHttp(url);
        System.out.println("baidu = " + response);
    }

    @RequestMapping("/httpPost")
    public String httpPost() {
        String url = "http://10.10.31.168:10008/decry";
        HttpBean bean = new HttpBean();
        bean.setKey("bce814a3e6905c35761cc52e8c1d2317");
        bean.setUrl("http://city-cache.clickwifi.net/2020-01-19_ratio-ap_diff_cache_com.sharedream.geek.app.all_340_434_1579385333.txt");

        String response = httpClient.postHttp(url, bean);

        System.out.println("httpPost = " + response);
        return response;
    }

    @RequestMapping("/httpsGet")
    public String httpsTest() {
//        https://tcc.taobao.com/cc/json/mobile_tel_segment.htm是阿里提供的一个简单查询手机信息的地址。
        
        String url = "https://tcc.taobao.com/cc/json/mobile_tel_segment.htm?tel=13548417409";
        String response = httpClient.getHttps(url);
        System.out.println("baidu = " + response);
        return response;
    }
}
