package com.geek.silenceap.service;

import com.geek.silenceap.config.FileProperties;
import com.geek.silenceap.controller.FileController;
import com.geek.silenceap.exception.FileException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@Service
public class FileService {

    private static final Logger logger = LoggerFactory.getLogger(FileService.class);

    private final Path fileStorageLocation;

    @Autowired
    public FileService(FileProperties fileProperties) {
        String configUploadDir = fileProperties.getUploadDir();
        logger.info("configUploadDir = {}", configUploadDir);

        this.fileStorageLocation = Paths.get(configUploadDir).toAbsolutePath().normalize();

        String pathStr = fileStorageLocation.toString();
        logger.info("pathStr = {}", pathStr);

        try {
            Files.createDirectories(this.fileStorageLocation);
        } catch (Exception ex) {
            throw new FileException("Could not create the directory where the uploaded files will be stored.", ex);
        }
    }

    /**
     * 存储文件到系统
     *
     * @param file 文件
     * @return 文件名
     */
    public String storeFile(MultipartFile file) {
        // Normalize file name

        String originalFilename = file.getOriginalFilename();
        logger.info("storeFile originalFilename = {}",originalFilename);

        String fileName = StringUtils.cleanPath(originalFilename);
        logger.info("storeFile fileName = {}",fileName);

        try {
            // Check if the file's name contains invalid characters
            if (fileName.contains("..")) {
                throw new FileException("Sorry! Filename contains invalid path sequence " + fileName);
            }

            // Copy file to the target location (Replacing existing file with the same name)
            Path targetLocation = this.fileStorageLocation.resolve(fileName);
            logger.info("storeFile 保存文件绝对路径 = {}",targetLocation.toString());

            // 文件的复制
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

            return fileName;
        } catch (IOException ex) {
            throw new FileException("Could not store file " + fileName + ". Please try again!", ex);
        }
    }

    /**
     * 加载文件
     *
     * @param fileName 文件名
     * @return 文件
     */
    public Resource loadFileAsResource(String fileName) {
        try {
            //resolve:将相对路径解析为绝对路径
            logger.info("loadFileAsResource fileName = {}",fileName);

            Path filePath = this.fileStorageLocation.resolve(fileName).normalize();
            logger.info("loadFileAsResource 部署环境的绝对路径 = {}",filePath.toString());
            logger.info("loadFileAsResource 部署环境的uri = {}",filePath.toUri().toString());

            Resource resource = new UrlResource(filePath.toUri());
            if (resource.exists()) {
                return resource;
            } else {
                throw new FileException("File not found " + fileName);
            }
        } catch (MalformedURLException ex) {
            throw new FileException("File not found " + fileName, ex);
        }
    }

}
