package com.geek.silenceap.controller;

import com.geek.silenceap.bean.User;
import com.geek.silenceap.common.CommonResponse;
import com.geek.silenceap.common.ResponseConstant;
import com.geek.silenceap.common.ResponseUtil;
import com.geek.silenceap.service.IUserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@EnableAutoConfiguration
@RequestMapping("/silence")
public class LoginController {

    private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    IUserService userService;

    @RequestMapping("/test")
    @ResponseBody
    public CommonResponse test() {
        logger.info("/test currenttime: {}", System.currentTimeMillis());
        return ResponseUtil.generateResponse("you are in service--7", true);
    }

    @RequestMapping("/findUsers")
    @ResponseBody
    public CommonResponse findUsers() {
        return ResponseUtil.generateResponse(userService.findUsers());
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public CommonResponse login(@RequestBody User user) {
        logger.info("/login currenttime: {}", System.currentTimeMillis());
        return userService.login(user);
    }

    @RequestMapping(value = "/addUser", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public CommonResponse addUser(@RequestBody User user) {
        int index = userService.addUser(user);
        String responseMsg = "";
        boolean result = false;
        if (index == 0) {
            responseMsg = "添加用户失败,请注意不要添加相同用户名的账号！/各个字段 长度限制！";
        } else {
            responseMsg = "添加成功！";
            result = true;
        }
        return ResponseUtil.generateResponse(responseMsg, result);
    }

    @RequestMapping(value = "/addUsers", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public CommonResponse addUsers(@RequestBody List<User> users) {
        int index = userService.addUsers(users);
        String responseMsg = "";
        boolean result = false;
        if (index == 0) {
            responseMsg = "批量添加数据失败！请注意单个用户信息不能有相同账号/单个用户信息必须有账号、密码";
        } else {
            responseMsg = "批量添加数据成功！";
            result = true;
        }
        return ResponseUtil.generateResponse(responseMsg, result);
    }

    @RequestMapping(value = "/selectByName", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public CommonResponse selectByName(@RequestBody User user) {
        List<User> users = userService.selectByName(user);
        String responseMsg = "";
        boolean result = false;
        if (users != null && users.size() != 0) {
            responseMsg = "查询成功！";
            result = true;
        } else {
            responseMsg = "查无此人！";
            result = false;
        }
        return ResponseUtil.fullResponse(responseMsg, result, users);
    }

    @RequestMapping(value = "/motifyByUserPhone", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public CommonResponse motifyByUserPhone(@RequestBody User user) {
        int index = userService.motifyByUserPhone(user);
        String responseMsg = "";
        boolean result = false;
        if (index == 0) {
            responseMsg = "修改密码失败，请注意必须要有账号、密码信息/是否有录入过该账号！";
        } else {
            responseMsg = "修改密码成功！";
            result = true;
        }
        return ResponseUtil.generateResponse(responseMsg,result);
    }

    @RequestMapping(value = "/motifyStateByUserPhone", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public CommonResponse motifyStateByUserPhone(@RequestBody User user) {
        int index = userService.motifyStateByUserPhone(user);
        String responseMsg = "";
        boolean result = false;
        if (index == 0) {
            responseMsg = "修改状态失败，请注意必须要有账号、状态信息/是否有录入过该账号！";
        } else {
            responseMsg = "修改状态成功！";
            result = true;
        }
        return ResponseUtil.generateResponse(responseMsg,result);
    }

    @RequestMapping(value = "/motifyUserInfoByUserPhone", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public CommonResponse motifyUserInfoByUserPhone(@RequestBody User user) {
        int index = userService.motifyInfoByUserPhone(user);
        String responseMsg = "";
        boolean result = false;
        if (index == 0) {
            responseMsg = "修改用户信息失败，请注意必须要有账号信息/是否有录入过该账号！";
        } else {
            responseMsg = "修改账号信息成功！";
            result = true;
        }
        return ResponseUtil.generateResponse(responseMsg,result);
    }
}
