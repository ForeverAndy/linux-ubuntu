package com.geek.silenceap.service.impl;

import com.geek.silenceap.bean.User;
import com.geek.silenceap.common.CommonResponse;
import com.geek.silenceap.common.ResponseConstant;
import com.geek.silenceap.common.ResponseUtil;
import com.geek.silenceap.mapper.UserMapper;
import com.geek.silenceap.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service("userService")
public class UserServiceImpl implements IUserService {

    private static final DateFormat DEFAULT_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Autowired
    UserMapper userMapper;

    /**
     * 登录
     *
     * @return true:成功
     */
    public CommonResponse login(User record) {
        if (record == null) {
            return ResponseUtil.generateResponse(ResponseConstant.FAIL);
        }
        String userphone = record.getUserphone();
        String userpassword = record.getUserpassword();
        if (StringUtils.isEmpty(userphone)) {
            return ResponseUtil.generateResponse(ResponseConstant.USERNAME_NULL);
        }
        if (StringUtils.isEmpty(userpassword)) {
            return ResponseUtil.generateResponse(ResponseConstant.USERPASSWORD_NULL);
        }

        //查询改用户状态
        List<User> users = selectByPhone(record);
        if (users == null || users.size() == 0) {
            return ResponseUtil.generateResponse(ResponseConstant.USERNAME_NULL);
        }

        User targetUser = users.get(0);
        if (!targetUser.getUserenable()) {
            return ResponseUtil.generateResponse(ResponseConstant.USER_FORBIDDEN);
        }
        String targetPassword = targetUser.getUserpassword();
        if (!userpassword.equals(targetPassword)) {
            return ResponseUtil.generateResponse(ResponseConstant.PASSWORD_NOTSAME);
        }

        //更新登录时间
        Date date = new Date();
        String now = DEFAULT_FORMAT.format(date);
        targetUser.setLogintime(now);
        int index = updateLoginTimeByUserName(targetUser);
        if (index == 0) {
            return ResponseUtil.generateResponse(ResponseConstant.INTERNAL_SERVER_ERROR);
        }
        return ResponseUtil.generateResponse(users);
    }

    /**
     * 判断是否已经存在相同用户名的账号
     *
     * @return true:存在
     */
    private boolean sameAcount(User record) {
        boolean result = false;

        //根据name判断是否存在同名的记录
        List<User> user = selectByPhone(record);
        if (user != null && user.size() != 0) {
            result = true;
        }
        return result;
    }

    /**
     * 单个账号合法性效验
     *
     * @param record
     * @return true: 合法
     */
    private boolean chargeUser(User record) {
        boolean result = false;
        String username = record.getUsername();
        String userphone = record.getUserphone();
        String userpassword = record.getUserpassword();

        if (StringUtils.isEmpty(username) || StringUtils.isEmpty(userphone) || StringUtils.isEmpty(userpassword)) {
            return result;
        }
        if (username.length() > 5 || userphone.length() > 11 || userpassword.length() > 20) {
            return result;
        }

        result = true;
        return result;
    }

    @Override
    public int addUser(User record) {
        int index = 0;
        boolean chargeUser = chargeUser(record);
        if (!chargeUser) {
            return index;
        }

        boolean result = sameAcount(record);
        if (result) {
            return index;
        }
        return userMapper.addUser(record);
    }

    @Override
    public int addUsers(List<User> records) {
        int index = 0;
        for (User item : records) {

            boolean chargeUser = chargeUser(item);
            if (!chargeUser) {
                return index;
            }

            //排除相同账号
            boolean result = sameAcount(item);
            if (result) {
                return index;
            }
        }
        return userMapper.addUsers(records);
    }

    @Override
    public List<User> findUsers() {
        return userMapper.findUsers();
    }

    @Override
    public int updateByPrimaryKey(User record) {

        return 0;
    }

    @Override
    public int updateLoginTimeByUserName(User record) {
        return userMapper.updateLoginTimeByUserName(record);
    }

    @Override
    public int motifyByUserPhone(User record) {
        int index = 0;

        boolean chargeUser = chargeUser(record);
        if (!chargeUser) {
            return index;
        }

        List<User> users = selectByPhone(record);
        if (users != null && users.size() != 0) {
            index = userMapper.motifyByUserPhone(record);
        }
        return index;
    }

    @Override
    public int motifyStateByUserPhone(User record) {
        int index = 0;
        String userphone = record.getUserphone();
        if (StringUtils.isEmpty(userphone)) {
            return index;
        }
        List<User> users = selectByPhone(record);
        if (users != null && users.size() != 0) {
            index = userMapper.motifyStateByUserPhone(record);
        }
        return index;
    }

    @Override
    public int motifyInfoByUserPhone(User record) {
        int index = 0;
        String userphone = record.getUserphone();
        if (StringUtils.isEmpty(userphone)) {
            return index;
        }
        List<User> users = selectByPhone(record);
        if (users != null && users.size() != 0) {
            index = userMapper.motifyInfoByUserPhone(record);
        }
        return index;
    }

    @Override
    public List<User> selectByName(User record) {
        return userMapper.selectByName(record);
    }

    @Override
    public List<User> selectByPhone(User record) {
        return userMapper.selectByPhone(record);
    }
}
