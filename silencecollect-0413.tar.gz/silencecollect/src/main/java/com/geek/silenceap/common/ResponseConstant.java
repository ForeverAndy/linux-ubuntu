package com.geek.silenceap.common;

public enum ResponseConstant {
    SUCCESS(10000,"操作成功"),
    FAIL(10001,"操作失败"),

    USERNAME_NULL(10002,"账号为空"),
    USERPASSWORD_NULL(10003,"密码为空"),
    USER_FORBIDDEN(10004,"账号被禁用"),
    PASSWORD_NOTSAME(10005,"密码不正确"),
    INTERNAL_SERVER_ERROR(10010,"服务内部错误");

    public int code;
    public String message;

    ResponseConstant(int code,String message) {
        this.code = code;
        this.message = message;
    }
}
