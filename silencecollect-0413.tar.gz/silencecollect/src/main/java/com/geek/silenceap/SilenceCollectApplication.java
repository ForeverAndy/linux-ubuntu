package com.geek.silenceap;

import com.geek.silenceap.config.FileProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties({FileProperties.class})
public class SilenceCollectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SilenceCollectApplication.class, args);
	}
}
