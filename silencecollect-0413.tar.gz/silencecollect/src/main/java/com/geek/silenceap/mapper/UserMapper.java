package com.geek.silenceap.mapper;

import com.geek.silenceap.bean.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserMapper {
    int addUser(User record);

    int addUsers(List<User> records);

    List<User> findUsers();

    int updateByPrimaryKey(User record);

    int updateLoginTimeByUserName(User record);

    int motifyByUserPhone(User record);

    int motifyStateByUserPhone(User record);

    int motifyInfoByUserPhone(User record);

    List<User> selectByName(User record);

    List<User> selectByPhone(User record);
}