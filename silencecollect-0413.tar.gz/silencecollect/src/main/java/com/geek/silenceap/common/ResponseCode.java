package com.geek.silenceap.common;

public enum ResponseCode {
    SUCCESS(10000),
    FAIL(10001),
    UNAUTHORIZED(401),
    NOT_FOUND(404),
    INTERNAL_SERVER_ERROR(500);

    public int code;

    ResponseCode(int code) {
        this.code = code;
    }
}
