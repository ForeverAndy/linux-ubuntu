package com.geek.silenceap.bean;

import java.io.Serializable;
import java.util.Date;

public class User {
    private Integer id;

    private String username;

    private String userphone;

    private String userpassword;

    private String wifilimit;

    private String bluetoothlimit;

    private Boolean userenable;

    private String createtime;

    private String logintime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getUserpassword() {
        return userpassword;
    }

    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword == null ? null : userpassword.trim();
    }

    public Boolean getUserenable() {
        return userenable;
    }

    public void setUserenable(Boolean userenable) {
        this.userenable = userenable;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getLogintime() {
        return logintime;
    }

    public void setLogintime(String logintime) {
        this.logintime = logintime;
    }

    public String getUserphone() {
        return userphone;
    }

    public void setUserphone(String userphone) {
        this.userphone = userphone;
    }

    public String getWifilimit() {
        return wifilimit;
    }

    public void setWifilimit(String wifilimit) {
        this.wifilimit = wifilimit;
    }

    public String getBluetoothlimit() {
        return bluetoothlimit;
    }

    public void setBluetoothlimit(String bluetoothlimit) {
        this.bluetoothlimit = bluetoothlimit;
    }
}