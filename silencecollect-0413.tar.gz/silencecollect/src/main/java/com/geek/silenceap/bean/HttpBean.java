package com.geek.silenceap.bean;

public class HttpBean {

    /**
     * key : bce814a3e6905c35761cc52e8c1d2317
     * url : http://city-cache.clickwifi.net/2020-01-19_ratio-ap_diff_cache_com.sharedream.geek.app.all_340_434_1579385333.txt
     */

    private String key;
    private String url;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
