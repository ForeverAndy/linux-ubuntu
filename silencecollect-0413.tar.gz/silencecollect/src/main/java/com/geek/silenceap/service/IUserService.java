package com.geek.silenceap.service;

import com.geek.silenceap.bean.User;
import com.geek.silenceap.common.CommonResponse;
import com.geek.silenceap.common.ResponseConstant;

import java.util.List;

public interface IUserService {
    int addUser(User record);

    int addUsers(List<User> records);

    List<User> findUsers();

    int updateByPrimaryKey(User record);

    int updateLoginTimeByUserName(User record);

    int motifyByUserPhone(User record);

    int motifyStateByUserPhone(User record);

    int motifyInfoByUserPhone(User record);

    List<User> selectByName(User record);

    List<User> selectByPhone(User record);

    CommonResponse login(User record);
}
